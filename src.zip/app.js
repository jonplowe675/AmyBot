var restify = require('restify');
var builder = require('botbuilder');

//=========================================================
// Bot Setup
//=========================================================

// Setup Restify Server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function () {
   console.log('%s listening to %s', server.name, server.url); 
});
  
// Create chat bot
var connector = new builder.ChatConnector({
    appId: process.env.MICROSOFT_APP_ID,
    appPassword: process.env.MICROSOFT_APP_PASSWORD
});
var bot = new builder.UniversalBot(connector);
server.post('/api/messages', connector.listen());

//=========================================================
// Bots Dialogs
//=========================================================

// Add global LUIS recognizer to bot
//var model = 'https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/60cd47e5-0ec3-4416-a3a3-4c045510fc2b?subscription-key=644f045ab4784303ae10308ba3531cc0&timezoneOffset=0.0&verbose=true&q=';
//var recognizer = new builder.LuisRecognizer(model);
//var dialog = new builder.IntentDialog({ recognizers: [recognizer] });
//bot.dialog('/', dialog);

//dialog.matches('built'), [

bot.dialog('/', [
    function (session) {
        //session.send should work but doesnt'
        session.send("Hello Jon");
        session.send("Hi my name is Amy and welcome to the Health age calculator from AXA.");
        session.send("It will take us about 10 minutes to complete the calculation.");
        
        //bot.beginDialog('/top');
        //session.beginDialog('/top');

        builder.Prompts.confirm(session, "Is this OK?");
    },
     
    function (session, results) {
        //check response and exit if no
        //session.userData.Prompts = results.response.confirm;
        session.send("output" + results.response);
        //console.send("output" + results.response.confirm);

        if (!results.response) {
            session.endDialog("OK please come and talk to me again")
        }
        
        
        session.send("The key information we will need is: Height, Weight, Waist and Hip measurements, Blood pressure, Cholesterol level & Fasting bloodglucose level");
        builder.Prompts.text(session, 'Please enter you Height (leave blank if unknown');
    },

    function (session, results) {   

        session.userData.height = results.response;
        session.send("height is" + session.userData.height);

        //Weight
        builder.Prompts.text(session, 'Please enter you Weight (leave blank if unknown');
     },

    function (session, results) {
 
        session.userData.weight = results.response;

       //Waist
        builder.Prompts.text(session, 'Please enter your Waist measurement (leave blank if unknown.');
     },

    function (session, results) {

        session.userData.waist = results.response;

        //Hip
        builder.Prompts.text(session, 'Please enter you Hip measurement (leave blank if unknown');
     },

    function (session, results) {

        session.userData.hip = results.response;

        //Blood pressure
        builder.Prompts.text(session, 'Please enter you Blood pressure level (leave blank if unknown');
     },

    function (session, results) {

        session.userData.blood = results.response;

        //Cholesterol level
        builder.Prompts.text(session, 'Please enter you Cholesterol level (leave blank if unknown');
     },

    function (session, results) {

        session.userData.cholesterol = results.response;

        //Fasting bloodglucose level
        builder.Prompts.text(session, 'Please enter you Fasting bloodglucose level (leave blank if unknown.');
    },
    function (session, results) {

        session.userData.fasting = results.response;
    }
     
        
        //Are you missing any of this information?
        // dont do it like this - just ask questions and allow them to be blank
        //if yes

//bot.dialog('/', dialog);




        
    
 /*bot.dialog('/top', [      
    function (session) { 
        //server.post('here');
        //console.post('console here');
        //builder.Prompts.text(session,' got here');
        builder.Prompts.confirm(session, "Is this OK?");
    },
    function (session, results) {
       //if (results.response==true) {
           // builder.Prompts.text('geek',results.response)}
        //else {
           // builder.Prompts.text('hello','you','guys')}

        session.userData.Prompts = result.response;    
        session.endDialog();
    }
    */
]);




